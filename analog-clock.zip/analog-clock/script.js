const canvas = document.getElementById('clock');
const ctx = canvas.getContext('2d');

function drawClock(hour, minute, second) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw clock face
    ctx.beginPath();
    ctx.arc(100, 100, 90, 0, 2 * Math.PI);
    ctx.fillStyle = '#fff';
    ctx.fill();
    ctx.strokeStyle = '#000';
    ctx.stroke();

    // Draw hour markers
    for (let i = 0; i < 12; i++) {
        let angle = (i * Math.PI) / 6; // 30 degrees
        ctx.beginPath();
        ctx.moveTo(100 + Math.cos(angle) * 70, 100 + Math.sin(angle) * 70);
        ctx.lineTo(100 + Math.cos(angle) * 90, 100 + Math.sin(angle) * 90);
        ctx.stroke();
    }

    // Draw hands
    const hourAngle = ((hour % 12) + minute / 60) * Math.PI / 6;
    const minuteAngle = (minute + second / 60) * Math.PI / 30;
    const secondAngle = (second / 60) * Math.PI / 30;

    // Hour hand
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(100, 100);
    ctx.lineTo(100 + Math.cos(hourAngle - Math.PI / 2) * 40, 100 + Math.sin(hourAngle - Math.PI / 2) * 40);
    ctx.stroke();

    // Minute hand
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(100, 100);
    ctx.lineTo(100 + Math.cos(minuteAngle - Math.PI / 2) * 60, 100 + Math.sin(minuteAngle - Math.PI / 2) * 60);
    ctx.stroke();

    // Second hand
    ctx.strokeStyle = 'red';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(100, 100);
    ctx.lineTo(100 + Math.cos(secondAngle - Math.PI / 2) * 70, 100 + Math.sin(secondAngle - Math.PI / 2) * 70);
    ctx.stroke();
}

function updateClock() {
    const now = new Date();
    drawClock(now.getHours(), now.getMinutes(), now.getSeconds());
}

setInterval(updateClock, 1000);
updateClock(); // Initial call to draw the clock immediately